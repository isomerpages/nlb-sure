---
layout: post
title:  Our Story Keeping It Alive Sequel
date:   2018-12-30
permalink: /school-resources/videos/our-story-keeping-it-alive-sequel
---

<iframe width="100%" height="400" src="https://www.youtube.com/embed/eyBKE_BynRo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>