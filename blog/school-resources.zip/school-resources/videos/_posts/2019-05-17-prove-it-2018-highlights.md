---
layout: post
title:  Prove It 2018 Highlights
date:   2019-05-17
permalink: /school-resources/videos/prove-it-2018-highlights
---

On the 12th of March 2018, a total of 39 schools consisting of 155 students participated in the Prove It! Contest at the National Library. The S.U.R.E. team would like to thank all the students and teachers who had participated. Here are the highlights of that day.

<iframe width="560" height="400" src="https://www.youtube.com/embed/LTylo_rrbpo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>