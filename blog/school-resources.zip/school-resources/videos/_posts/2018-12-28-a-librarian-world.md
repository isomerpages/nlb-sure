---
layout: post
title:  A Librarian's World
date:   2018-12-28
permalink: /school-resources/videos/a-librarian-world
---

<iframe width="100%" height="400" src="https://www.youtube.com/embed/wkLUtrExWMU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>