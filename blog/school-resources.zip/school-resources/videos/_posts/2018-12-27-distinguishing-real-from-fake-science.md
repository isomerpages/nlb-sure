---
layout: post
title:  Distinguishing Real from Fake Science
date:   2018-12-27
permalink: /school-resources/videos/distinguishing-real-from-fake-science
---

<iframe width="100%" height="400" src="https://www.youtube.com/embed/J18A52Gitg0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>