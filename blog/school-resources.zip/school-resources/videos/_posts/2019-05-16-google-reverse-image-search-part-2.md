---
layout: post
title:  Google Reverse Image Search (Part 2)
date:   2019-05-16
permalink: /school-resources/videos/google-reverse-image-search-part-2
---

<iframe width="100%" height="400" src="https://www.youtube.com/embed/9YxCKeu3fBg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>