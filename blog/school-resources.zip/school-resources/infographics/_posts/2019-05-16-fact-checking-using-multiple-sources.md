---
layout: post
title:  Fact checking using multiple sources
date:   2019-05-16
permalink: /school-resources/infographics/fact-checking-using-multiple-sources
---

![Infographic for Fact checking using multiple sources](/images/digital-economy.png)

If you receive any dubious information, you can check the facts using credible sources before you share.

View the [infographic](/documents/Multiple-Sources-English_revised.pdf).