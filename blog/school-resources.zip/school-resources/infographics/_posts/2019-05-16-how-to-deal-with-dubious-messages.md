---
layout: post
title:  How to deal with dubious messages
date:   2019-05-16
permalink: /school-resources/infographics/how-to-deal-with-dubious-messages
---

![Banner for How to deal with dubious messages](/images/banner-dubious-messages.png)

Bogus stories can be easily spread through SMS and social messaging tools and apps. Before you share, verify the information using the steps in this [tip sheet](/documents/Dubious-Messages-Eng.pdf).