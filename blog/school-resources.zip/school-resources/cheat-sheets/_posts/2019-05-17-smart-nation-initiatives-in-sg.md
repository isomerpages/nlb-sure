---
layout: post
title:  Smart Nation Initiatives in Singapore
date:   2019-05-17
permalink: /school-resources/cheat-sheets/smart-nation-initiatives-in-sg
---

![Smart Nation Initiatives poster](/images/smart-nation-initiatives.jpg)

Smart Nation initiative was launched by Prime Minister Lee Hsien Loong on 24 November 2014. The aim is to build a “nation where people live meaningful and fulfilled lives, enabled seamlessly by technology, offering exciting opportunities for all”.

Download our [cheat sheet](/document/NLB_Cheatsheet_SmartNation.pdf) to find out more about Singapore’s information technology initiatives.