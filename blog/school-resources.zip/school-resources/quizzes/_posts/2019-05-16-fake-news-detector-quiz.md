---
layout: post
title:  Fake News Detector Quiz
date:   2019-05-16
permalink: /school-resources/quizzes/fake-news-detector-quiz
---

![Banner for Fake News Detector quiz](/images/banner-fake-news-detector.png)

How good are you at telling what is real news or otherwise? Try this [quiz](https://goo.gl/forms/AWw7DGfGApZnIrsx2){:target="_blank"} now!