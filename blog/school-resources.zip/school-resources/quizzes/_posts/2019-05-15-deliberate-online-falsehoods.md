---
layout: post
title:  Deliberate Online Falsehoods
date:   2019-05-15
permalink: /school-resources/quizzes/deliberate-online-falsehoods
---

![Banner for Fake News Detector quiz](/images/banner-deliberate-online-falsehoods.png)

On 10 January 2018, the Parliament of Singapore unanimously voted in favour of setting up a Select Committee to study the problem of deliberate online falsehoods.  How much do you know about this development?  Try this [quiz](https://goo.gl/forms/80RNdfHb5DzyV4a52){:target="_blank"} now!